package Agencia;

public class Promocao {

	private int id;
	private String nome;
	private double valor;
	private Destino destino;

	public Promocao(int i, Object object, double valor2) {
		// TODO Auto-generated constructor stub
	}

	public Destino getDestino() {
		return destino;
	}

	public void setDestino(Destino destino) {
		this.destino = destino;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

}